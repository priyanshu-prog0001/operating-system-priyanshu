// Small counting-semaphore class (portable C++11 replacement for sem_t / C++20 std::counting_semaphore)
#pragma once
#include <mutex>
#include <condition_variable>

class Semaphore {
    std::mutex m_;
    std::condition_variable cv_;
    int count_;
public:
    explicit Semaphore(int count = 0) : count_(count) {}
    void wait() {                       // P operation
        std::unique_lock<std::mutex> lk(m_);
        cv_.wait(lk, [this] { return count_ > 0; });
        --count_;
    }
    void post() {                       // V operation
        { std::lock_guard<std::mutex> lk(m_); ++count_; }
        cv_.notify_one();
    }
};
